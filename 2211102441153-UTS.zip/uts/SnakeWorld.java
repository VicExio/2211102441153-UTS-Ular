import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * It is a 20 by 20 square world
 * 
 * @author (Ethan) 
 * @version (a version number or a date)
 */
public class SnakeWorld extends World
{
    Score score = new Score();
    public YouLose youLose = new YouLose();
    public SnakeWorld()
    {    
        super(30, 20, 20);
        
        int x = Greenfoot.getRandomNumber(getWidth());
        int y = Greenfoot.getRandomNumber(getHeight());
        addObject(new SnakeHead(),15,10);
        addObject(new Bomb(), x, y);


        
        addFood();
    }
    
    public Score getScore()
    {
        return score;
    }
    
    public void addFood()
    {
        int x = Greenfoot.getRandomNumber(getWidth());
        int y = Greenfoot.getRandomNumber(getHeight());
        addObject(new Food(), x, y);
        
        addObject(score, 3, 1);
    }
    
    public void addBom()
    {
        int x = Greenfoot.getRandomNumber(getWidth());
        int y = Greenfoot.getRandomNumber(getHeight());
        addObject(new Food(), x, y);
        
        addObject(score, 3, 2);
    }
    
    public void displayYouLose()
    {
        addObject(youLose, 20, 20);
        youLose.setLocation(getWidth()/2,getHeight()/2);
        Greenfoot.stop();
    }
    
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is what the snake is going to eat so that it gets bigger
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Food extends Actor
{
    public Food() 
    {
       
    }    
    
    public void act()
    {
        
    }
}
